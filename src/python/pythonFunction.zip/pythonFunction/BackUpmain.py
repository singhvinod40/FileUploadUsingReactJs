from flask import Flask, request, jsonify
from google.api_core.client_options import ClientOptions
from google.cloud import documentai

app = Flask(__name__)

project_id = "656678246625"
location = "us"
processor_id = "f02e8de4a22da6ae"
mime_type = "application/pdf"
field_mask = "text,entities,pages.pageNumber"
processor_version_id = "a4943f618dea7a81"

@app.route('/process-document', methods=['POST'])
def hello_http():
    data = request.get_json()
    file_path = data.get('file_path')

    if not file_path:
        return jsonify({"error": "file_path not provided"}), 400

    opts = ClientOptions(api_endpoint=f"{location}-documentai.googleapis.com")
    client = documentai.DocumentProcessorServiceClient(client_options=opts)

    if processor_version_id:
        name = client.processor_version_path(
            project_id, location, processor_id, processor_version_id
        )
    else:
        name = client.processor_path(project_id, location, processor_id)

    file_path = file_path.strip('"')

    with open(file_path, "rb") as image:
        image_content = image.read()

    raw_document = documentai.RawDocument(content=image_content, mime_type=mime_type)

    process_options = documentai.ProcessOptions(
        individual_page_selector=documentai.ProcessOptions.IndividualPageSelector(
            pages=[1]
        )
    )

    request = documentai.ProcessRequest(
        name=name,
        raw_document=raw_document,
        field_mask=field_mask,
        process_options=process_options,
    )

    result = client.process_document(request=request)
    document = result.document

    response = {
        "text": document.text,
        "entities": [{"type": entity.type_, "mention_text": entity.mention_text} for entity in document.entities]
    }

    return jsonify(response), 200

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
