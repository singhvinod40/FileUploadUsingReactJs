from flask import Flask, request, jsonify
from google.api_core.client_options import ClientOptions
from google.cloud import documentai, storage
import os

app = Flask(__name__)

project_id = "656678246625"
location = "us"
processor_id = "f02e8de4a22da6ae"
mime_type = "application/pdf"
field_mask = "text,entities,pages.pageNumber"
processor_version_id = "a4943f618dea7a81"

def download_blob(bucket_name, source_blob_name, destination_file_name):
    """Downloads a blob from the bucket."""
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(source_blob_name)
    blob.download_to_filename(destination_file_name)

    print(
        f"Downloaded storage object {source_blob_name} from bucket {bucket_name} to local file {destination_file_name}."
    )

@app.route('/process-document', methods=['POST'])
def hello_http():
    data = request.get_json()
    gcs_uri = data.get('gcs_uri')

    if not gcs_uri:
        return jsonify({"error": "gcs_uri not provided"}), 400

    # Parse the GCS URI
    if gcs_uri.startswith("gs://"):
        gcs_uri = gcs_uri[5:]
    else:
        return jsonify({"error": "Invalid gcs_uri format. Must start with 'gs://'"}), 400

    bucket_name, file_path = gcs_uri.split('/', 1)

    # Temporary file path to download the file
    temp_file_path = "/tmp/temp_file.pdf"

    try:
        # Download the file from GCS
        download_blob(bucket_name, file_path, temp_file_path)

        opts = ClientOptions(api_endpoint=f"{location}-documentai.googleapis.com")
        client = documentai.DocumentProcessorServiceClient(client_options=opts)

        if processor_version_id:
            name = client.processor_version_path(
                project_id, location, processor_id, processor_version_id
            )
        else:
            name = client.processor_path(project_id, location, processor_id)

        with open(temp_file_path, "rb") as image:
            image_content = image.read()

        raw_document = documentai.RawDocument(content=image_content, mime_type=mime_type)

        process_options = documentai.ProcessOptions(
            individual_page_selector=documentai.ProcessOptions.IndividualPageSelector(
                pages=[1]
            )
        )

        request = documentai.ProcessRequest(
            name=name,
            raw_document=raw_document,
            field_mask=field_mask,
            process_options=process_options,
        )

        result = client.process_document(request=request)
        document = result.document

        response = {
            "text": document.text,
            "entities": [{"type": entity.type_, "mention_text": entity.mention_text} for entity in document.entities]
        }

        # Clean up the temporary file
        os.remove(temp_file_path)

        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
