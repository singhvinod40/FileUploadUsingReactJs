from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess

app = Flask(__name__)
CORS(app)  # This will enable CORS for all routes


@app.route('/run-script', methods=['POST'])
def run_script():
    data = request.get_json()
    file_path = data.get('file_path')

    if not file_path:
        return jsonify({"error": "file_path not provided"}), 400

    try:
        # Run the Python script with the file_path argument
        result = subprocess.run(['python', 'test.py', file_path], capture_output=True, text=True)

        # Check for errors
        if result.returncode != 0:
            return jsonify({"error": result.stderr}), 500

        return jsonify({"output": result.stdout}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
