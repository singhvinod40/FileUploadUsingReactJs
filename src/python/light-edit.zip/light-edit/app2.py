from flask import Flask, request, jsonify
from flask_cors import CORS
import subprocess
import json

app = Flask(__name__)
CORS(app)

@app.route('/run-script', methods=['POST'])
def run_script():
    data = request.get_json()
    file_path = data.get('file_path')

    if not file_path:
        return jsonify({"error": "file_path not provided"}), 400

    try:
        result = subprocess.run(['python', 'test2.py', file_path], capture_output=True, text=True)

        if result.returncode != 0:
            return jsonify({"error": result.stderr}), 500

        # Load the JSON output from the script
        output = json.loads(result.stdout)

        response = {
            "text": output.get("text", ""),
            "entities": output.get("entities", []),
            "address": output.get("address", {})
        }

        return jsonify(response), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
